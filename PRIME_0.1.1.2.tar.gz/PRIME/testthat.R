library(testthat)
library(PRIME)

test_check("PRIME")
